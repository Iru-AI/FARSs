﻿namespace FARS
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            facilitiesToolStripMenuItem = new ToolStripMenuItem();
            servicesToolStripMenuItem = new ToolStripMenuItem();
            utToolStripMenuItem = new ToolStripMenuItem();
            roooToolStripMenuItem = new ToolStripMenuItem();
            room1ToolStripMenuItem = new ToolStripMenuItem();
            room2ToolStripMenuItem = new ToolStripMenuItem();
            room3ToolStripMenuItem = new ToolStripMenuItem();
            multipurposeHallToolStripMenuItem = new ToolStripMenuItem();
            loungeToolStripMenuItem = new ToolStripMenuItem();
            kitchenToolStripMenuItem = new ToolStripMenuItem();
            mH1ToolStripMenuItem = new ToolStripMenuItem();
            mH2ToolStripMenuItem = new ToolStripMenuItem();
            lounge1ToolStripMenuItem = new ToolStripMenuItem();
            lounge2ToolStripMenuItem = new ToolStripMenuItem();
            kitchen1ToolStripMenuItem = new ToolStripMenuItem();
            kitchen2ToolStripMenuItem = new ToolStripMenuItem();
            airconAdjustmentToolStripMenuItem = new ToolStripMenuItem();
            cleanerToolStripMenuItem = new ToolStripMenuItem();
            fixerToolStripMenuItem = new ToolStripMenuItem();
            gymToolStripMenuItem = new ToolStripMenuItem();
            gymHallToolStripMenuItem = new ToolStripMenuItem();
            dataGridView1 = new DataGridView();
            dateToolStripMenuItem = new ToolStripMenuItem();
            timeToolStripMenuItem = new ToolStripMenuItem();
            button1 = new Button();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { facilitiesToolStripMenuItem, servicesToolStripMenuItem, utToolStripMenuItem, dateToolStripMenuItem, timeToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(426, 25);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // facilitiesToolStripMenuItem
            // 
            facilitiesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { roooToolStripMenuItem, multipurposeHallToolStripMenuItem, loungeToolStripMenuItem, kitchenToolStripMenuItem, gymToolStripMenuItem });
            facilitiesToolStripMenuItem.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            facilitiesToolStripMenuItem.ForeColor = Color.MediumPurple;
            facilitiesToolStripMenuItem.Name = "facilitiesToolStripMenuItem";
            facilitiesToolStripMenuItem.Size = new Size(68, 21);
            facilitiesToolStripMenuItem.Text = "Facilities";
            // 
            // servicesToolStripMenuItem
            // 
            servicesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { airconAdjustmentToolStripMenuItem, cleanerToolStripMenuItem, fixerToolStripMenuItem });
            servicesToolStripMenuItem.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            servicesToolStripMenuItem.ForeColor = Color.MediumPurple;
            servicesToolStripMenuItem.Name = "servicesToolStripMenuItem";
            servicesToolStripMenuItem.Size = new Size(67, 21);
            servicesToolStripMenuItem.Text = "Services";
            // 
            // utToolStripMenuItem
            // 
            utToolStripMenuItem.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            utToolStripMenuItem.ForeColor = Color.MediumPurple;
            utToolStripMenuItem.Name = "utToolStripMenuItem";
            utToolStripMenuItem.Size = new Size(62, 21);
            utToolStripMenuItem.Text = "Utilities";
            utToolStripMenuItem.Click += utToolStripMenuItem_Click;
            // 
            // roooToolStripMenuItem
            // 
            roooToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { room1ToolStripMenuItem, room2ToolStripMenuItem, room3ToolStripMenuItem });
            roooToolStripMenuItem.Name = "roooToolStripMenuItem";
            roooToolStripMenuItem.Size = new Size(180, 22);
            roooToolStripMenuItem.Text = "Rooms";
            roooToolStripMenuItem.Click += roooToolStripMenuItem_Click;
            // 
            // room1ToolStripMenuItem
            // 
            room1ToolStripMenuItem.Name = "room1ToolStripMenuItem";
            room1ToolStripMenuItem.Size = new Size(180, 22);
            room1ToolStripMenuItem.Text = "Room 1";
            // 
            // room2ToolStripMenuItem
            // 
            room2ToolStripMenuItem.Name = "room2ToolStripMenuItem";
            room2ToolStripMenuItem.Size = new Size(180, 22);
            room2ToolStripMenuItem.Text = "Room 2";
            // 
            // room3ToolStripMenuItem
            // 
            room3ToolStripMenuItem.Name = "room3ToolStripMenuItem";
            room3ToolStripMenuItem.Size = new Size(180, 22);
            room3ToolStripMenuItem.Text = "Room 3";
            // 
            // multipurposeHallToolStripMenuItem
            // 
            multipurposeHallToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { mH1ToolStripMenuItem, mH2ToolStripMenuItem });
            multipurposeHallToolStripMenuItem.Name = "multipurposeHallToolStripMenuItem";
            multipurposeHallToolStripMenuItem.Size = new Size(180, 22);
            multipurposeHallToolStripMenuItem.Text = "Multipurpose Hall";
            // 
            // loungeToolStripMenuItem
            // 
            loungeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { lounge1ToolStripMenuItem, lounge2ToolStripMenuItem });
            loungeToolStripMenuItem.Name = "loungeToolStripMenuItem";
            loungeToolStripMenuItem.Size = new Size(180, 22);
            loungeToolStripMenuItem.Text = "Lounge";
            // 
            // kitchenToolStripMenuItem
            // 
            kitchenToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { kitchen1ToolStripMenuItem, kitchen2ToolStripMenuItem });
            kitchenToolStripMenuItem.Name = "kitchenToolStripMenuItem";
            kitchenToolStripMenuItem.Size = new Size(180, 22);
            kitchenToolStripMenuItem.Text = "Kitchen";
            // 
            // mH1ToolStripMenuItem
            // 
            mH1ToolStripMenuItem.Name = "mH1ToolStripMenuItem";
            mH1ToolStripMenuItem.Size = new Size(180, 22);
            mH1ToolStripMenuItem.Text = "MH 1";
            // 
            // mH2ToolStripMenuItem
            // 
            mH2ToolStripMenuItem.Name = "mH2ToolStripMenuItem";
            mH2ToolStripMenuItem.Size = new Size(180, 22);
            mH2ToolStripMenuItem.Text = "MH 2";
            // 
            // lounge1ToolStripMenuItem
            // 
            lounge1ToolStripMenuItem.Name = "lounge1ToolStripMenuItem";
            lounge1ToolStripMenuItem.Size = new Size(180, 22);
            lounge1ToolStripMenuItem.Text = "Lounge 1";
            // 
            // lounge2ToolStripMenuItem
            // 
            lounge2ToolStripMenuItem.Name = "lounge2ToolStripMenuItem";
            lounge2ToolStripMenuItem.Size = new Size(180, 22);
            lounge2ToolStripMenuItem.Text = "Lounge 2";
            // 
            // kitchen1ToolStripMenuItem
            // 
            kitchen1ToolStripMenuItem.Name = "kitchen1ToolStripMenuItem";
            kitchen1ToolStripMenuItem.Size = new Size(180, 22);
            kitchen1ToolStripMenuItem.Text = "Kitchen 1";
            // 
            // kitchen2ToolStripMenuItem
            // 
            kitchen2ToolStripMenuItem.Name = "kitchen2ToolStripMenuItem";
            kitchen2ToolStripMenuItem.Size = new Size(180, 22);
            kitchen2ToolStripMenuItem.Text = "Kitchen 2";
            // 
            // airconAdjustmentToolStripMenuItem
            // 
            airconAdjustmentToolStripMenuItem.Name = "airconAdjustmentToolStripMenuItem";
            airconAdjustmentToolStripMenuItem.Size = new Size(180, 22);
            airconAdjustmentToolStripMenuItem.Text = "Aircon adjustment";
            // 
            // cleanerToolStripMenuItem
            // 
            cleanerToolStripMenuItem.Name = "cleanerToolStripMenuItem";
            cleanerToolStripMenuItem.Size = new Size(180, 22);
            cleanerToolStripMenuItem.Text = "Cleaner";
            // 
            // fixerToolStripMenuItem
            // 
            fixerToolStripMenuItem.Name = "fixerToolStripMenuItem";
            fixerToolStripMenuItem.Size = new Size(180, 22);
            fixerToolStripMenuItem.Text = "Fixer";
            // 
            // gymToolStripMenuItem
            // 
            gymToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { gymHallToolStripMenuItem });
            gymToolStripMenuItem.Name = "gymToolStripMenuItem";
            gymToolStripMenuItem.Size = new Size(180, 22);
            gymToolStripMenuItem.Text = "Gym";
            // 
            // gymHallToolStripMenuItem
            // 
            gymHallToolStripMenuItem.Name = "gymHallToolStripMenuItem";
            gymHallToolStripMenuItem.Size = new Size(180, 22);
            gymHallToolStripMenuItem.Text = "Gym Hall";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.Azure;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(81, 69);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(263, 159);
            dataGridView1.TabIndex = 3;
            // 
            // dateToolStripMenuItem
            // 
            dateToolStripMenuItem.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateToolStripMenuItem.ForeColor = Color.MediumPurple;
            dateToolStripMenuItem.Name = "dateToolStripMenuItem";
            dateToolStripMenuItem.Size = new Size(47, 21);
            dateToolStripMenuItem.Text = "Date";
            // 
            // timeToolStripMenuItem
            // 
            timeToolStripMenuItem.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            timeToolStripMenuItem.ForeColor = Color.MediumPurple;
            timeToolStripMenuItem.Name = "timeToolStripMenuItem";
            timeToolStripMenuItem.Size = new Size(48, 21);
            timeToolStripMenuItem.Text = "Time";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(341, 244);
            button1.Name = "button1";
            button1.Size = new Size(73, 25);
            button1.TabIndex = 4;
            button1.Text = "Request";
            button1.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(426, 281);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.None;
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "Form2";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem facilitiesToolStripMenuItem;
        private ToolStripMenuItem servicesToolStripMenuItem;
        private ToolStripMenuItem utToolStripMenuItem;
        private ToolStripMenuItem roooToolStripMenuItem;
        private ToolStripMenuItem room1ToolStripMenuItem;
        private ToolStripMenuItem room2ToolStripMenuItem;
        private ToolStripMenuItem room3ToolStripMenuItem;
        private ToolStripMenuItem multipurposeHallToolStripMenuItem;
        private ToolStripMenuItem mH1ToolStripMenuItem;
        private ToolStripMenuItem mH2ToolStripMenuItem;
        private ToolStripMenuItem loungeToolStripMenuItem;
        private ToolStripMenuItem lounge1ToolStripMenuItem;
        private ToolStripMenuItem lounge2ToolStripMenuItem;
        private ToolStripMenuItem kitchenToolStripMenuItem;
        private ToolStripMenuItem kitchen1ToolStripMenuItem;
        private ToolStripMenuItem kitchen2ToolStripMenuItem;
        private ToolStripMenuItem gymToolStripMenuItem;
        private ToolStripMenuItem gymHallToolStripMenuItem;
        private ToolStripMenuItem airconAdjustmentToolStripMenuItem;
        private ToolStripMenuItem cleanerToolStripMenuItem;
        private ToolStripMenuItem fixerToolStripMenuItem;
        private DataGridView dataGridView1;
        private ToolStripMenuItem dateToolStripMenuItem;
        private ToolStripMenuItem timeToolStripMenuItem;
        private Button button1;
    }
}